Primer proyecto de TSTL:

* El proyecto se encuentra en el cuaderno de Jupyter "Proyecto TSTL.ipynb" donde también viene el reporte. 
* En la carpeta "data" están los datasets que se usaron para el proyecto.
* En la carpeta "snowballstemmer" se encuentra el código que se utilizó para el prepocesamiento de los tweets.
* En el archivo de python "Proyecto+TSTL.py" se encuentra el mismo código que en el cuaderno de Jupyter en
  formato de script.


